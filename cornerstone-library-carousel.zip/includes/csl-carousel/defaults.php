<?php

/**
 * Default Values
 */

return array(
	'id'                => '',
	'class'             => '',
	'style'             => '',
	'max_visible_items' => 3,
	'auto_play'         => false,
	'auto_valign'       => false,
	'pause_hover'       => false,
	'pagination_type'   => 'none'
);