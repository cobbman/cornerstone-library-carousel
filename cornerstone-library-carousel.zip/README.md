# cornerstone-carousel
A carousel element for the Cornerstone Page Builder in WordPress. See http://cornerstonelibrary.com

![Cornerstonen Library](http://cornerstonelibrary.com/wp-content/uploads/2015/09/carousel-example.gif "Cornerstone Carousel")

### Learn more about Cornerstone: http://theme.co/cornerstone

### Learn more about Owl: http://www.owlgraphic.com/owlcarousel/

___

This element was made by the D3FY Development Group. http://d3fy.com
